# jsecret

simple and fast tool to detect sensitive data in the source code such as javascript files or others 

# install 

`go install -v github.com/raoufmaklouf/jsecret@latest`

# Usage

`cat jsfiles.txt | jsceret`

`echo http://test.tld/main.js | jsecret`


Big thank to https://twitter.com/medmahmoudi_619 for helpful help with regex
