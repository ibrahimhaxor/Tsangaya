package fourohme

type Header struct {
	Key   string
	Value string
}
