#!/bin/bash

# JSON Web Token
echo "========== JSON Web Token =========="

echo " hahahah"